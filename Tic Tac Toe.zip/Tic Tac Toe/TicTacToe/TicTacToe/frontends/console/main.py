def preview(cells):
    print(cells[:3], cells[3:6], cells[6:], sep="\n")
    
preview("XXOXO O ")